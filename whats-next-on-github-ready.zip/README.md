# What's Next On — Entertainment Discovery Website

**Live website:** https://whatsnexton.com/  
**Portfolio:** https://brendanmmcnamara.com/

## Overview
What's Next On is an entertainment-focused web experience. This repository contains a deployable **compiled frontend build** and supporting static assets, rather than the original editable project source.

## Included files
- `index.html` — site entry point
- `assets/` — bundled JavaScript and CSS
- Image files — backgrounds, posters and social sharing image
- `favicon.svg`, `robots.txt`, `.htaccess` — supporting website files

## UX and visual design focus
- Entertainment-oriented content presentation
- Visual hierarchy and editorial styling
- Responsive interface layout
- Navigation and discovery experience

## Deployment
Upload the files in the repository root together to a compatible static web host. Keep the `assets/` directory next to `index.html`. The included `.htaccess` is intended for Apache-based hosting and may not apply to other hosts.

## Development note
The JavaScript and CSS are minified production bundles. Original React components, build configuration, and package manifest are **not included**. If the original Replit project becomes available, it can be added separately after review.

## Security and licensing
Do not add credentials, environment files, private user data, or third-party assets without appropriate rights. A basic pattern scan of the supplied files is not a complete security audit.
